<?php $baseurl = "http://localhost/ces/"?>
<!DOCTYPE html>
<html lang="en">

<title></title>

<head>
    <link rel="icon" type="image/png" href="<?=$baseurl?>assets/images/puc.png"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
    <link rel="stylesheet" href="<?=$baseurl?>assets/css/style.css">
</head>