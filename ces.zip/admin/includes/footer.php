  <div class="footer">
                        <div class="pull-right">
                             Developed by <strong>...</strong> 
                        </div>
                        <div>
                            <strong>All Rights Reserved by ....</strong>
                        </div>
                    </div>