

       <script type="text/javascript" src="<?=$base?>/assets/plugins/jquery/jquery.min.js"></script>

       
        <script type="text/javascript" src="<?=$base?>/assets/plugins/metis-menu/metisMenu.min.js"></script>
        <script type="text/javascript" src="<?=$base?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        
        <script type="text/javascript" src="<?=$base?>/assets/plugins/slim-scroll/jquery.slimscroll.min.js"></script>
        <script src="<?=$base?>/assets/plugins/c3/d3.v3.min.js" charset="utf-8"></script>       
        <script src="<?=$base?>/assets/plugins/c3/c3.min.js"></script>
        <script type="text/javascript" src="../../../../../../../www.gstatic.com/charts/loader.js"></script>
        <!-- <script src="<?=$base?>/assets/plugins/calendar/moment.min.js"></script> -->
        <!-- <script src="<?=$base?>/assets/plugins/calendar/fullcalendar.min.js"></script> -->
        <!-- <script src="<?=$base?>/assets/plugins/ui/jquery-ui.js"></script>        -->
        <script src="<?=$base?>/assets/plugins/map/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="<?=$base?>/assets/plugins/map/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?=$base?>/assets/plugins/morris_chart/morris.js"></script>
        <script src="<?=$base?>/assets/plugins/morris_chart/raphael-2.1.0.min.js"></script>
        <!-- PAGE LEVEL FILES -->
        <script src="<?=$base?>/assets/plugins/data-tables/jquery.dataTables.js"></script>
        <script src="<?=$base?>/assets/plugins/data-tables/dataTables.tableTools.js"></script>
        <script src="<?=$base?>/assets/plugins/data-tables/dataTables.bootstrap.js"></script>
        <script src="<?=$base?>/assets/plugins/data-tables/dataTables.responsive.js"></script>
        <script src="<?=$base?>/assets/plugins/data-tables/tables-data.js"></script>
        <!-- Custom FILES -->
        <script type="text/javascript" src="<?=$base?>/assets/js/custom.js"></script>
            <!-- <script src="<?=$base?>/assets/plugins/toastr/toastr.min.js"></script> -->
        <script type="text/javascript" src="<?=$base?>/assets/js/index.js"></script>
        <!-- <script  src="<?=$base?>/assets/js/jquery-ui.js"></script> -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

        <script src="<?=$base?>/assets/plugins/select/select2.js"></script>
        
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js">
</script>
<script>
        $(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
});

$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
    $(".alert-dismissible").alert('close');
});
</script>


