  !function($) {
	  "use strict";
  $(function(){
  
	  
		$('.scrollerchat').slimScroll({
		  height: '396px'
	  });
  
			});
  
		
	  }(window.jQuery);	