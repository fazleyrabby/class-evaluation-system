

!function($) {
    "use strict";
	
	 $.material.init();
	
$(function(){
 $('.show-image').magnificPopup({type: 'image'});
});
	
	
	
	}(window.jQuery);	